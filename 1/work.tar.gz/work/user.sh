#!/bin/bash

echo "本地连接请输入1；url文件请输入2；"
read fileType

if [ -z "${fileType}" ];then
	fileType=1
fi

echo "请输入地址："
read filePath

echo ${filePath}
case $fileType in
1)
    if [ -z "${filePath}" ];then
      filePath1="./users.csv"
    else
      filePath1=${filePath}
    fi
  ;;
2)
    filePath1="./users.csv"
    wget -O $filePath1 https://test.rongtuitui.cn/users.csv
  ;;
esac

cat $filePath1  | while read line
do

    lineOne=${line}
    oneF=`expr index "$lineOne" ";"`
    usernameData=(${lineOne:0:oneF-1})
    usernameData1=(${usernameData//@/ })
    usernameData2=(${usernameData1[0]//./ })
    username=(${usernameData2[0]:0:1}${usernameData2[1]})


    lineTwo=(${lineOne:oneF})
    twoF=`expr index "$lineTwo" ";"`
    passwdData=(${lineTwo:0:twoF-1})
    passwdData1=(${passwdData//// })
    passwd=(${passwdData1[2]}${passwdData1[0]}${username})


    lineThree=(${lineTwo:twoF})
    threeF=`expr index "$lineThree" ";"`
    groupData=(${lineThree:0:threeF-1})
    if [[ -z $groupData ]];
    then
      groupData=${username}
    fi



    lineFour=(${lineThree:threeF})
    fourF=`expr index "$lineFour" ";"`
    shareFile=(${lineFour:0:fourF-1})
    if [[ -z $groupData ]];
    then
      shareFile=''
    fi



    #如果文件夹不存在，创建文件夹
    if [[ ! -d $shareFile ]]; then
        mkdir $shareFile
        echo "shareFile add $shareFile 成功!"
    else
        echo "shareFile  $shareFile 存在!"
    fi


    if [[ -z  `getent group $groupData` ]]
    then
      sudo groupadd $groupData
      echo "group add $groupData 成功!"
    else
     echo "group  $groupData 存在!"
    fi


    if id -u ${username} >/dev/null 2>&1 ;then
      echo " ${username} exists."
#      break
    else
  		sudo useradd -s /bin/bash -m $username -g $groupData
    	echo "$username:$passwd" | sudo chpasswd
  		echo "User $username's password has been changed!"
  		 `ln -s $shareFile /home/$username`
    fi



done
